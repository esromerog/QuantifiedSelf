import React from 'react';
import Accordion from 'react-bootstrap/Accordion';


function Listas({texto, titulo, icon}) {
  return (
    /*
    <Accordion.Item eventKey={titulo} key={titulo}>
      <Accordion.Header key={titulo}>
        <i className={icon}></i>{titulo}
      </Accordion.Header>
      <Accordion.Body>{texto}</Accordion.Body>
    </Accordion.Item>
    */
   <div class="accordion-item" key={titulo}>
      <h2 class="accordion-header">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" key={titulo}>
          <i className={icon}></i>{titulo}
        </button>
      </h2>
      <body>{texto}</body>
   </div>
  );
}
export default function Expand({data}) {
  const devicesList=data?.map((datos) => <Listas texto={datos.content} titulo={datos.heading} icon={datos.icon}/>);
  return (
    <Accordion>
      {devicesList}
    </Accordion>
  );
};